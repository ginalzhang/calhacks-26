import { test, expect, _electron } from '@playwright/test';
import path from 'node:path';
import { readdirSync, mkdtempSync } from 'node:fs';
import os from 'node:os';
test('packaged panel is sandboxed, local and nonactivating with bundled helper',async()=>{
  test.setTimeout(60_000);
  const env=Object.fromEntries(Object.entries(process.env).filter((entry):entry is [string,string]=>entry[1]!==undefined));delete env.ELECTRON_RUN_AS_NODE;
  const app=await _electron.launch({executablePath:path.resolve('out/Steady-darwin-arm64/Steady.app/Contents/MacOS/Steady'),args:[`--user-data-dir=${mkdtempSync(path.join(os.tmpdir(),'steady-phase02-e2e-'))}`,'--use-fake-device-for-media-stream=fps=30','--use-fake-ui-for-media-stream'],env,timeout:15000});
  try{
    const page=await app.firstWindow();await expect(page.getByText('Steady',{exact:true}).first()).toBeVisible();
    // Main-inspector evaluation can pause Electron's monotonic RTT measurement.
    // Wait through native startup via renderer IPC before inspecting the main VM.
    await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).nativeClockReady),{timeout:5000}).toBe(true);
    await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).speechDiagnostics?.phase),{timeout:5000}).toBe('idle');
    const info=await app.evaluate(({BrowserWindow,app})=>{
      const w=BrowserWindow.getAllWindows()[0]!;
      return {packaged:app.isPackaged,size:w.getSize(),focusable:w.isFocusable(),alwaysOnTop:w.isAlwaysOnTop(),allSpaces:w.isVisibleOnAllWorkspaces(),url:w.webContents.getURL()};
    });
    expect(info).toMatchObject({packaged:true,size:[320,560],focusable:false,alwaysOnTop:true,allSpaces:true});
    expect(info.url).toMatch(/^file:/);
    const status=await page.evaluate(()=>window.steady.status());expect(status.realInput).toBe(false);expect(status.fault).toBeNull();expect(status.native?.buttonDown).toBe(false);
    expect(status.speechDiagnostics).toMatchObject({session:null,audioBuffers:0,transcriberResults:0,detectorResults:0,acceptedUtterances:0});
    expect(await page.evaluate(async()=>{try{await fetch('https://example.com/steady-outbound-probe');return false;}catch{return true;}})).toBe(true);
    // Chromium offline emulation proves bundled inference needs no fetch.
    // Physical network-off camera/telemetry evidence still requires an operator.
    await app.context().setOffline(true);
    const workerFilename=readdirSync('.vite/renderer/main_window/assets').find(name=>name.startsWith('vision.worker-'))!;
    for(const mode of ['head','palm'] as const){
      const result=await page.evaluate(async({workerFilename,mode})=>new Promise<{delegate:string;valid:boolean}>((resolve,reject)=>{
        const worker=new Worker(new URL(`assets/${workerFilename}`,location.href),{type:'module'});
        const timeout=setTimeout(()=>{worker.terminate();reject(new Error('Local model initialization timeout'));},15000);
        let delegate='';worker.onerror=event=>{clearTimeout(timeout);worker.terminate();reject(new Error(event.message));};
        worker.onmessage=async event=>{
          if(event.data.type==='fault'){clearTimeout(timeout);worker.terminate();reject(new Error(event.data.message));}
          if(event.data.type==='ready'){
            delegate=event.data.delegate;const canvas=new OffscreenCanvas(640,480);canvas.getContext('2d')!.fillRect(0,0,640,480);
            const bitmap=await createImageBitmap(canvas);worker.postMessage({type:'frame',bitmap,frameId:1,generation:1,captureTimestamp:performance.now()},[bitmap]);
          }
          if(event.data.type==='sample'){clearTimeout(timeout);worker.terminate();resolve({delegate,valid:event.data.sample.valid});}
        };worker.postMessage({type:'initialize',mode,assetRoot:'steady-resource://assets/'});
      }),{workerFilename,mode});
      expect(['GPU','CPU']).toContain(result.delegate);expect(result.valid).toBe(false);
    }
    // Settings and panel are separate packaged file:// windows. Verify their
    // control/report transport without opening any camera or microphone.
    const settingsPromise=app.waitForEvent('window');await page.evaluate(()=>window.steady.openSettings());const settings=await settingsPromise;await settings.waitForLoadState();
    await expect(settings.getByText('Voice input is deferred to Phase 04. Use the panel controls or configured keys.')).toBeVisible();
    await expect(settings.getByRole('button',{name:'Enable microphone',exact:true})).toHaveCount(0);
    await expect(settings.getByRole('button',{name:'Set up speech assets',exact:true})).toHaveCount(0);
    for(const attempt of ['microphone','assets'] as const){
      const error=await settings.evaluate(async attempt=>{try{if(attempt==='microphone')await window.steady.microphone(true);else await window.steady.installSpeechAssets();return null;}catch(error){return String(error);}},attempt);
      expect(error).toContain('deferred to Phase 04');
    }
    await settings.getByRole('button',{name:'Disable microphone',exact:true}).click();
    const voiceStatus=await page.evaluate(()=>window.steady.status());
    expect(voiceStatus.microphoneEnabled).toBe(false);
    expect(voiceStatus.speechDiagnostics).toMatchObject({audioBuffers:0,transcriberResults:0,acceptedUtterances:0});
    const received=page.evaluate(()=>new Promise<boolean>(resolve=>{
      const channel=new BroadcastChannel('steady-review-origin-probe');const timer=setTimeout(()=>{channel.close();resolve(false);},2000);
      channel.onmessage=event=>{clearTimeout(timer);channel.close();resolve(event.data==='probe');};
    }));
    await settings.evaluate(()=>{const channel=new BroadcastChannel('steady-review-origin-probe');channel.postMessage('probe');setTimeout(()=>channel.close(),100);});
    expect(await received).toBe(true);
    expect(await page.evaluate(()=>typeof (globalThis as any).require)).toBe('undefined');
    await settings.getByRole('button',{name:'Start camera probe',exact:true}).click();
    const frameCount=async()=>Number((await settings.locator('[aria-labelledby="camera-heading"] [role="status"]').textContent())?.match(/(\d+) frames/)?.[1]??0);
    await expect.poll(frameCount,{timeout:15000}).toBeGreaterThan(2);
    const beforeCollapse=await frameCount();await page.evaluate(()=>window.steady.collapse(true));
    await expect.poll(frameCount,{timeout:10000}).toBeGreaterThan(beforeCollapse+2);
    await settings.getByRole('button',{name:'Stop camera probe',exact:true}).click();
    await expect(settings.locator('[aria-labelledby="camera-heading"] [role="status"]')).toContainText('Camera off');
    await page.evaluate(() => {
      // Synthetic model outputs exercise the full packaged setup workflow. The
      // real bundled models were separately initialized above; no hardware claim.
      const root = globalThis as any; root.syntheticAnchor = { x: .5, y: .5 };
      root.Worker = class {
        onmessage: ((event: {data: any}) => void) | null = null; onerror = null; stopped = false;
        postMessage(message: any): void {
          if (message.type === 'initialize') setTimeout(() => this.onmessage?.({ data: { type: 'ready', delegate: 'CPU' } }), 1);
          if (message.type === 'frame') {
            message.bitmap.close();
            setTimeout(() => { if (!this.stopped) this.onmessage?.({ data: { type: 'sample', sample: { generation: message.generation, frameId: message.frameId, captureTimestamp: message.captureTimestamp, mode: 'head', valid: true, anchor: root.syntheticAnchor, qualityReason: 'synthetic fixture', selectedHand: null } } }); }, 1);
          }
        }
        terminate(): void { this.stopped = true; }
      };
    });
    await page.evaluate(()=>window.steady.collapse(false));
    await settings.getByRole('button',{name:'Start camera probe',exact:true}).click();
    await expect(settings.locator('[aria-labelledby="camera-heading"] [role="status"]')).toContainText('synthetic fixture');
    await expect.poll(frameCount,{timeout:10000}).toBeGreaterThan(2);
    await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).settings?.cameraId),{timeout:5000}).not.toBe('');
    await settings.getByRole('button',{name:'Begin five-position calibration',exact:true}).click();
    await expect(settings.getByTestId('setup-message')).toContainText('Hold a neutral position',{timeout:5000});
    const positions = [{x:.5,y:.5},{x:.3,y:.5},{x:.8,y:.5},{x:.5,y:.3},{x:.5,y:.8}];
    const steps = ['left','right','up','down'];
    for (let index=0;index<positions.length;index++) {
      await page.evaluate(position => { (globalThis as any).syntheticAnchor = position; }, positions[index]);
      await settings.getByRole('button',{name:'Capture / Retry',exact:true}).click();
      if(index<4) await expect(settings.getByText(`Current step: ${steps[index]}`,{exact:true})).toBeVisible({timeout:5000});
      else await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).settings?.calibrations.length),{timeout:5000}).toBe(1);
    }
    await expect(settings.getByTestId('setup-message')).toContainText('Five-position calibration saved',{timeout:5000});
    const calibrated = await page.evaluate(()=>window.steady.status());
    expect(calibrated.settings?.calibrations[0]).toMatchObject({gain:1,smoothing:50,neutral:{x:.5,y:.5}});
    expect(calibrated.canvasConfirmed).toBe(false); expect(calibrated.native?.buttonDown).toBe(false); expect(calibrated.native?.state).toBe('PAUSED'); expect(calibrated.nativeClockReady).toBe(true);
    await page.evaluate(()=>window.steady.action('resume'));
    expect((await page.evaluate(()=>window.steady.status())).fault).toContain('Phase 03');
    await settings.getByRole('button',{name:'Recenter neutral',exact:true}).click();
    await expect(settings.getByTestId('setup-message')).toContainText('Capturing a new neutral',{timeout:2000});
    await expect(settings.getByTestId('setup-message')).toContainText('Recenter saved',{timeout:5000});
    expect((await page.evaluate(()=>window.steady.status())).native?.buttonDown).toBe(false);
    const closed = settings.waitForEvent('close');
    await settings.evaluate(()=>window.steady.closeSettings()); await closed;
    const reopenedPromise=app.waitForEvent('window');await page.evaluate(()=>window.steady.openSettings());
    const reopened=await reopenedPromise;await reopened.waitForLoadState();
    await expect(reopened.locator('[aria-labelledby="camera-heading"] [role="status"]')).toContainText('synthetic fixture');
    await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).nativeClockReady)).toBe(true);
    // Deliberately fault only the fake helper with an unordered sample. Camera
    // Stop must still work after the Pause request rejects, including remount.
    await page.evaluate(async()=>{
      const current=await window.steady.status();
      window.steady.submitSample({generation:current.generation,frameId:0,captureTimestamp:performance.now(),mode:'head',valid:false,anchor:null,qualityReason:'synthetic unordered fixture'});
    });
    await expect.poll(()=>page.evaluate(async()=>(await window.steady.status()).nativeFault)).toContain('stale-or-unordered');
    await reopened.getByRole('button',{name:'Stop camera probe',exact:true}).click();
    await expect(reopened.locator('[aria-labelledby="camera-heading"] [role="status"]')).toContainText('Camera off');
    await page.evaluate(()=>window.steady.openSettings());
    expect((await page.evaluate(()=>window.steady.status())).nativeFault).toContain('stale-or-unordered');
  }finally{await app.close();}
});
